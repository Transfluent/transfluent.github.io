#!/bin/bash
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

if [ ! $1 ]; then
  echo "Usage $0 [email] [password] [filename] [type] [source_language] [target_languages] [callback_url]"
  echo "E.g. $0 you@example.org pass1234 example.json json-file en-gb fi-fi,fr-fr,de-de 'https://example.org/translation_done'"
  exit 1
fi
if [ ! -f "$3" ]; then
  echo -e "${RED}File not found!${NC}"
  exit 1
fi
if [ ! $8 ]; then
  API_URL="https://transfluent.com/v2/"
  CURL_PARAMS=""
else
  API_URL="https://$8"
  CURL_PARAMS="--insecure"
fi

type curl >/dev/null 2>&1 || { echo >&2 "Missing depedency: cURL"; exit 1; }
type openssl >/dev/null 2>&1 || { echo >&2 "Missing depedency: OpenSSL"; exit 1; }

AUTH_RESPONSE=`curl $CURL_PARAMS -d "email=$1&password=$2" $API_URL"authenticate/"`
if [[ $AUTH_RESPONSE == *"ERROR"* ]]
then
  echo -e "${RED}LOGIN FAILED${NC}"
  exit 1
else
  echo -e "LOGIN: ${GREEN}SUCCESS${NC}"
fi

TOKEN=`echo "$AUTH_RESPONSE" | cut -d : -f 4  | cut -d '"' -f 2`
#echo `curl $API_URL"customer/name/?token=$TOKEN"`

# http://api.transfluent.com/api/FileSave.html
echo -e "Uploading the file.."
PAYLOAD=`(echo -n "{\"content\":\""; openssl base64 < "$3"; echo -n "\", \"type\":\"$4\",\"language\":\"$5\",\"identifier\": \"$3\",\"token\":\"$TOKEN\"}") | tr -d '\n'`
RESPONSE=`curl $CURL_PARAMS --header "Content-Type: application/json" -d "$PAYLOAD" $API_URL"file/save/"`
if [[ $RESPONSE == *"ERROR"* ]]
then
  echo -e "${RED}FILE UPLOAD FAILED!${NC}"
  echo "RESPONSE FROM API: $RESPONSE"
  exit 1
else
  echo -e "FILE UPLOAD: ${GREEN}SUCCESS${NC}"
fi

TARGET_LANGUAGES=`(echo -n '["'; (echo "$6" | sed -r 's/[,]+/","/g'); echo -n '"]') | tr -d '\n'`
echo -e "Sending request to translate the file.."
RESPONSE=`curl $CURL_PARAMS --header "Content-Type: application/json" -d "{\"language\": \"$5\", \"identifier\": \"$3\",\"target_languages\": $TARGET_LANGUAGES, \"level\":\"business\", \"callback_url\": \"$7\", \"token\":\"$TOKEN\"}" $API_URL"file/translate/"`
if [[ $RESPONSE == *"ERROR"* ]]
then
  echo -e "${RED}TRANSLATION REQUEST FAILED!${NC}"
  echo "RESPONSE FROM API: $RESPONSE"
  exit 1
else
  echo -e "FILE SUBMITTED FOR TRANSLATION: ${GREEN}SUCCESS${NC}"
fi

echo -e "${GREEN}ALL DONE, EXITING..${NC}"
exit 0